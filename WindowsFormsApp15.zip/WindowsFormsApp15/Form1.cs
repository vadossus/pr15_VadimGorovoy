﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.IO;

namespace WindowsFormsApp15
{
    public partial class Form1 : Form
    {
        private PredmetUkazatel predmetUkazatel = new PredmetUkazatel();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox2.Text))
                {
                    MessageBox.Show("Вы не ввели в текстовое поле, выбрали кол-во страниц или не ввели название файла в текстовое поле");
                    return;
                }

                string slovo = textBox1.Text;
                int.TryParse(textBox3.Text, out int page);
                if (page < 1 || page > 10)
                {
                    MessageBox.Show("Ошибка: Страниц не может быть больше 10 или меньше 1");
                    return;
                }
                else
                {
                    if (predmetUkazatel.index.ContainsKey(slovo) && predmetUkazatel.index[slovo].Contains(page))
                    {
                        listBox1.Items.Add($"{slovo}: {string.Join(", ", predmetUkazatel.index[slovo])}");
                    }
                    else
                    {
                        MessageBox.Show("Такого слова или страницы нету");
                        return;
                    }

                    textBox1.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}");
                return;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string file = textBox2.Text;
                if (file != "")
                {
                    predmetUkazatel.ZagruzitVFile(file);
                    MessageBox.Show("Файл загружен");
                }
                else
                {
                    MessageBox.Show("Вы не заполнили данное поле");
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Файл не найден");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                List<string> list = new List<string>();
                string file = textBox2.Text;
                if (file != "" && listBox1.Items.Count > 0)
                {
                    foreach (var items in listBox1.Items)
                    {
                        list.Add(items.ToString());
                    }
                    predmetUkazatel.SoxranitVFile(file,list);
                }
                else
                {
                    MessageBox.Show("Вы не заполнили данное поле");
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("Файл не найден");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string search = Microsoft.VisualBasic.Interaction.InputBox("Введите то, что вы хотите найти", "Поиск");

            List<int> searchResults = new List<int>();
            bool isNumber = int.TryParse(search, out int page);

            foreach (var item in listBox1.Items)
            {
                string word = item.ToString().Split(':')[0].Trim();

                if ((isNumber && predmetUkazatel.Poisk(word).Contains(page)) ||
                    (!isNumber && word.Contains(search)))
                {
                    searchResults.AddRange(predmetUkazatel.Poisk(word));
                }
            }

            if (searchResults.Count > 0)
            {
                MessageBox.Show($"Результаты поиска для \"{search}\": {string.Join(", ", searchResults)}");
            }
            else
            {
                MessageBox.Show("Ничего не найдено.");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1) 
            {
                string selectedItem = listBox1.Items[listBox1.SelectedIndex].ToString(); 
                listBox1.Items.RemoveAt(listBox1.SelectedIndex); 
                MessageBox.Show($"Элемент \"{selectedItem}\" успешно удален."); 
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления из списка."); 
            }
        }
    }
}
