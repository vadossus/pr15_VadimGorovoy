﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp15
{
    class PredmetUkazatel
    {
        public Dictionary<string, List<int>> index = new Dictionary<string, List<int>>();

        public void SoxranitVFile(string fileName, List<string> list)
        {
            using (StreamWriter writer = new StreamWriter(fileName))
            {
                foreach (var item in list)
                {
                    writer.WriteLine(item.ToString());
                }
            }
            MessageBox.Show("Информация успешно записана в файл.");
        }

        public void ZagruzitVFile(string fileName)
        {
            index = File.ReadAllLines(fileName)
           .Select(line => line.Split(new[] { ':' }, StringSplitOptions.RemoveEmptyEntries))
           .ToDictionary(split => split[0].Trim(),
                     split => split[1].Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                                     .Select(int.Parse).ToList());
        }

        public List<int> Poisk(string slovo)
        {
            return index.ContainsKey(slovo) ? index[slovo] : new List<int>();
        }


    }
}
